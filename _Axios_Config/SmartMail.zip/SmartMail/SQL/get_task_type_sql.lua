-- get_task_type_sql.lua
--
-- Prepared for SmartMail Quick Config
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
--------------------------------------------------------------------------------------
-- Change log
-- Feb 23 2012	New File
--------------------------------------------------------------------------------------
sql([[
SELECT decision_flag "DECISION_FLAG"
FROM act_reg
INNER JOIN rproc_task ON act_reg.incident_id = rproc_task.incident_id
WHERE
act_reg.act_reg_id =  ]] .. ACT_REG_ID)
