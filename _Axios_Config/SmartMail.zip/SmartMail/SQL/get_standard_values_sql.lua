--------------------------------------------------------------------------------------
-- get_standard_values_sql.lua

-- Prepared for AGS SmartMail Quick Config (Version 1.0)
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
-- This script is required if you want to execute more than one SQL (Lua) file.
-- 02/20/2012 New File
-- 08/01/2012 Extend to get common information from parent requests and format data for ticket types
--------------------------------------------------------------------------------------

sql([[
SELECT     	inc_major.inc_major_sc "MAJOR_CATEGORY_SC",
			inc_major.inc_major_n "MAJOR_CATEGORY_N"
FROM        inc_cat INNER JOIN
				inc_major ON inc_cat.inc_major_id = inc_major.inc_major_id INNER JOIN
                incident ON inc_cat.inc_cat_id = incident.inc_cat_id
WHERE     	incident.incident_id = ]] .. EVENT_ID)

sql([[
SELECT     	inc_cat.inc_cat_sc "CAUSE_CATEGORY_SC"
FROM        inc_cat INNER JOIN
				incident ON inc_cat.inc_cat_id = incident.cause_id
WHERE     	incident.incident_id = ]] .. EVENT_ID)

if EVENT_TYPE == "c" then
	sql([[
	SELECT 
		sub_event_type "SUB_EVENT_TYPE"
	FROM inc_data
	INNER JOIN act_reg on act_reg.incident_id = inc_data.incident_id
	WHERE act_reg_id =]] .. ACT_REG_ID)
else
	SUB_EVENT_TYPE = ""
end

function getEventTypeU(PARM_EVENT_TYPE, PARM_SUB_EVENT_TYPE)
	--	Set Event Type to be used on email subjects 
	--	This is recognized by the Mailbox Reader
	returnValue = string.upper(PARM_EVENT_TYPE)
	if PARM_EVENT_TYPE == "i" then
		returnValue = ""
	elseif PARM_EVENT_TYPE == "c" then
		if PARM_SUB_EVENT_TYPE == "s" then
			returnValue = "S"
		else
			returnValue = "R"
		end
	end
	
	return returnValue
end

EVENT_TYPE_U = getEventTypeU(EVENT_TYPE, SUB_EVENT_TYPE)

---------------------------------------------------------------------------
--	Functionality below this line is implementation specific
---------------------------------------------------------------------------

--	Set Text Event Type value to be used on email subject and within emails
if (string.lower(SUB_EVENT_TYPE or "none") == "s")
	or ((MAJOR_CATEGORY_SC or "") == "REQUEST") then
	EVENT_TYPE_N_EXT = "Service Request"
	EVENT_TYPE_EXT = "s"
else
	EVENT_TYPE_N_EXT = EVENT_TYPE_N
	EVENT_TYPE_EXT = EVENT_TYPE
end


sql([[
SELECT 
	usr.contact_print "FRENCH"
FROM incident
	INNER JOIN usr on usr.usr_id = incident.aff_usr_id
WHERE 
  incident.incident_id = ]] .. EVENT_ID)

-- Get Parent Event Id if any - otherwise set to current event
sql([[Select u_num2 "PARENT_EVENT_ID"
	from inc_data
	where inc_data.incident_id = ]] .. EVENT_ID )
	
if (PARENT_EVENT_ID == 0) then
	PARENT_EVENT_ID = EVENT_ID
end

--	Get Service and Service Offering Short Codes
sql([[
SELECT
	serv_off.serv_off_n "SERVICE_OFFERING_N"
FROM 
	inc_data 
	INNER JOIN
	serv_off ON inc_data.serv_off_id = serv_off.serv_off_id 
	WHERE
inc_data.incident_id = ]] .. PARENT_EVENT_ID)

if ((SERVICE_OFFERING_N or "") == "") then
	TICKET_TYPE_FOR_EMAIL = MAJOR_CATEGORY_N
else
	TICKET_TYPE_FOR_EMAIL = SERVICE_OFFERING_N .. " " .. MAJOR_CATEGORY_N
end

sql([[
SELECT     	inc_major.inc_major_sc "PAR_MAJOR_CATEGORY_SC",
			inc_major.inc_major_n "PAR_MAJOR_CATEGORY_N"
FROM        inc_cat INNER JOIN
				inc_major ON inc_cat.inc_major_id = inc_major.inc_major_id INNER JOIN
                incident ON inc_cat.inc_cat_id = incident.inc_cat_id
WHERE     	incident.incident_id = ]] .. PARENT_EVENT_ID)


if ((SERVICE_OFFERING_N or "") == "") then
	PAR_TICKET_TYPE_FOR_EMAIL = PAR_MAJOR_CATEGORY_N
else
	PAR_TICKET_TYPE_FOR_EMAIL = SERVICE_OFFERING_N .. " " .. PAR_MAJOR_CATEGORY_N
end

LOGGER:debug("TICKET_TYPE_FOR_EMAIL: " .. stringify(TICKET_TYPE_FOR_EMAIL) .. ", PAR_TICKET_TYPE_FOR_EMAIL: " .. stringify(PAR_TICKET_TYPE_FOR_EMAIL))

if PARENT_EVENT_ID == EVENT_ID then
	PAR_EVENT_REF = EVENT_REF
	PAR_SUB_EVENT_TYPE = SUB_EVENT_TYPE
	PAR_EVENT_TYPE = EVENT_TYPE
	PAR_EVENT_TYPE_U = EVENT_TYPE_U
else
	sql([[
		SELECT 
			incident.event_type "PAR_EVENT_TYPE",
			incident.incident_ref "PAR_EVENT_REF",
			inc_data.sub_event_type "PAR_SUB_EVENT_TYPE"
		FROM incident
			INNER JOIN inc_data
			ON incident.incident_id = inc_data.incident_id
		WHERE incident.incident_id =]] .. PARENT_EVENT_ID)
		
	PAR_EVENT_TYPE_U = getEventTypeU(PAR_EVENT_TYPE, PAR_SUB_EVENT_TYPE)
end
LOGGER:debug("get_standard_values_sql PAR_EVENT_TYPE: " .. stringify(PAR_EVENT_TYPE) .. ", PAR_EVENT_REF: " .. stringify(PAR_EVENT_REF)
	.. ", PAR_SUB_EVENT_TYPE: " .. stringify(PAR_SUB_EVENT_TYPE) .. ", PAR_EVENT_TYPE_U: " .. stringify(PAR_EVENT_TYPE_U))



