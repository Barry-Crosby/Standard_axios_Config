-- get_language_sql.lua
--
-- Prepared for SmartMail Quick Config
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
--------------------------------------------------------------------------------------
-- Change log
-- Feb 23 2012	New File
--------------------------------------------------------------------------------------

sql([[
SELECT 
	usr.contact_print "FRENCH"
FROM incident
	INNER JOIN usr on usr.usr_id = incident.aff_usr_id
WHERE 
  incident.incident_id = ]] .. EVENT_ID)
