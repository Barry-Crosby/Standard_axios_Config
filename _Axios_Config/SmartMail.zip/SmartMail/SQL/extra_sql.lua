--------------------------------------------------------------------------------------
-- extra_sql.lua

-- Prepared for AGS SmartMail Quick Config (Version 1.0)
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
-- This script is required if you want to execute more than one SQL (Lua) file.
-- 02/20/2010 added SQL for finding event types for Service Requests. The variable strassystVersion is defined in BaseConfig.lua
-- 02/20/2010 introduced variables EVENT_TYPE_N_EXT and EVENT_TYPE_EXT to handle V9 Service Request events. For use in V9 html templates
--------------------------------------------------------------------------------------

-- required for V9 to determine if a change request is a service request
if tonumber(string.sub((strassystVersion or "0"), 1, 1)) >= 9 then
	if EVENT_TYPE == "c" then
		sql([[
		SELECT 
			sub_event_type "SUB_EVENT_TYPE"
		FROM inc_data
		INNER JOIN act_reg on act_reg.incident_id = inc_data.incident_id
		WHERE act_reg_id =]] .. ACT_REG_ID)
	end
	if string.lower(SUB_EVENT_TYPE or "none") == "s" then
		EVENT_TYPE_N_EXT = "Service Request"
		EVENT_TYPE_EXT = "s"
	else
		EVENT_TYPE_N_EXT = EVENT_TYPE_N
		EVENT_TYPE_EXT = EVENT_TYPE
	end
else
	EVENT_TYPE_N_EXT = EVENT_TYPE_N
	EVENT_TYPE_EXT = EVENT_TYPE
end
if EVENT_TYPE ~= EVENT_TYPE_EXT then
	LOGGER:info("EVNT TYPE IS NOW " .. EVENT_TYPE_N_EXT .. " Event type: " .. EVENT_TYPE_EXT .. "  not event type name of " .. EVENT_TYPE_N)
end
--- end of V9 event types -----

if include_SQL ~= nil then
	for sID, RunSQL in pairs(include_SQL) do
		LOGGER:info("Starting " .. RunSQL)
		dofile(strPathToSql .. RunSQL)
		LOGGER:info("Completed " .. RunSQL)
	end
end
