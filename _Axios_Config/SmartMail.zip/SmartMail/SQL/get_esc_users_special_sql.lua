-- get_esc_users_sql.lua
--
-- Prepared for SmartMail Quick Config
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
---------------------------------------------------------------------------------------- 
-- Change log
-- Feb 22 2012	New File
--------------------------------------------------------------------------------------

multi_row_sql([[
SELECT     usr.usr_sc "ESC_USR_SC"
FROM  act_reg 
	INNER JOIN incident ON act_reg.incident_id = incident.incident_id 
	INNER JOIN sla_prior ON incident.inc_prior_id = sla_prior.inc_prior_id
	INNER JOIN esc_usr ON sla_prior.sla_prior_id = esc_usr.sla_prior_id 
	INNER JOIN usr ON esc_usr.usr_id = usr.usr_id
WHERE
	sla_prior.esc_level =  ]] .. ESC_LEVEL .. [[
	and (usr.usr_sc = 'ZZ_MANAGER'
	or usr.usr_sc = 'ZZ_ASSIGNED')
	and act_reg_id = ]] .. ACT_REG_ID)

bEscManager = false
bEscAssignee = false

if ESC_USR_SC then
	for _, uname in ipairs(ESC_USR_SC) do
	   if uname == "ZZ_MANAGER" then
		   bEscManager = true
		   LOGGER:debug("Found esc manager")
		end
	end

	for _, uname in ipairs(ESC_USR_SC) do
	   if uname == "ZZ_ASSIGNED" then
		   bEscAssignee = true
		   LOGGER:debug("Found esc assignee")
		end
	end
end
