-- get_action_contact_user_sql.lua
--
-- Prepared for AGS SmartMail Quick Config (Version 3.0)
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
---------------------------------------------------------------------------------------- 
-- Retrieves information on the contact user that took an action on the event
-- Variable Names in a string format:
--    Contact User Short code:	ACTION_CONTACT_USR_SC
--    Contact User Name: 		ACTION_CONTACT_USR_N
--    Contact User Email: 		ACTION_CONTACT_EMAIL_ADD
---------------------------------------------------------------------------------------- 

--------------------------------------------------------------------------------------
-- Change log
-- Aug 09 2009	Initial version
--------------------------------------------------------------------------------------

sql([[
SELECT	
	usr.usr_sc "ACTION_CONTACT_USR_SC", 
	usr.usr_n "ACTION_CONTACT_USR_N", 
	act_reg.aff_ctc_email "ACTION_CONTACT_EMAIL_ADD"
FROM	act_reg
	INNER JOIN usr ON act_reg.aff_usr_id = usr.usr_id
WHERE act_reg.act_reg_id = ]] .. ACT_REG_ID)

LOGGER:debug("ACTION_CONTACT_USR_SC: " .. (ACTION_CONTACT_USR_SC or "") .. ", ACTION_CONTACT_EMAIL_ADD: " .. (ACTION_CONTACT_EMAIL_ADD or ""))