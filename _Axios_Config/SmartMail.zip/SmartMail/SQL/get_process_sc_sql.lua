-- get_process_sc.lua
--
-- Prepared for SmartMail Quick Config
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
---------------------------------------------------------------------------------------- 
-- Get the short code of teh proess associated with the event
-- Variable Name in a string format:
--    Process Short Code:					GET_PROCESS_SC
--------------------------------------------------------------------------------------
-- Change log
-- Sep 1 2009	New File
--------------------------------------------------------------------------------------

sql([[
select rproc_hdr.rproc_hdr_sc  "GET_PROCESS_SC"
FROM
	rproc_hdr 
	INNER JOIN inc_data on inc_data.u_num1 = rproc_hdr.rproc_hdr_id
	INNER JOIN act_reg on inc_data.incident_id = act_reg.incident_id
WHERE
	act_reg.act_reg_id = ]] .. ACT_REG_ID)