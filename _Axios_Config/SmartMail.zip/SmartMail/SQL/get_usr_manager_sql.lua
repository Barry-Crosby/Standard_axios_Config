-- get_usr_manager_sql.lua
--
-- Prepared for SmartMail Quick Config
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
---------------------------------------------------------------------------------------- 
-- Change log
-- Jul 31 2012	New File
--------------------------------------------------------------------------------------

sql(
[[
SELECT mgr.usr_n 'MANAGER_NAME',
	mgr.email_add 'MANAGER_EMAIL'
	FROM usr
		INNER JOIN usr mgr
	ON usr.line_manager_id = mgr.usr_id
	WHERE usr.usr_sc = ']] .. AFF_USR_SC .. [[']])

LOGGER:debug("get_usr_manager_sql MANAGER_NAME: " .. stringify(MANAGER_NAME) .. ", MANAGER_EMAIL: " .. stringify(MANAGER_EMAIL)
		.. ", AFF_USR_SC: " .. stringify(AFF_USR_SC))
