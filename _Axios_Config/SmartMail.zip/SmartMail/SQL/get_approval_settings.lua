-- get_authorization_settings.lua
--
--	Determine what links should be included in authoriztion emails 
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
---------------------------------------------------------------------------------------- 

--------------------------------------------------------------------------------------
-- Change log
-- Jul 11 2012	New file
--------------------------------------------------------------------------------------

AUTH_LINK_NET = false
AUTH_LINK_WEB = false
AUTH_LINK_WEB_DETAILS = false
ASSYST_USER_FROM_ALIAS = ""

sUserToCheck = ""
sAssUsrSC = (ASS_USR_SC or "")
if (sAssUsrSC == "") then
	AUTH_LINK_WEB = true
else
	if string.len(sAssUsrSC) > 3 then
		if string.sub(sAssUsrSC, 1, 3) == "ZZ_" then
			sUserToCheck = string.sub(sAssUsrSC, 4)
			AUTH_LINK_NET = true
		else
			AUTH_LINK_WEB = true
		end
	end

	if sUserToCheck ~= "" then
		sql([[
		SELECT	
			assyst_usr.assyst_usr_sc "ASSYST_USER_FROM_ALIAS"
		FROM	assyst_usr
		WHERE assyst_usr.assyst_usr_sc = ']] .. sUserToCheck .. [[']])
		ASSYST_USER_FROM_ALIAS = (ASSYST_USER_FROM_ALIAS or "")
		if ASSYST_USER_FROM_ALIAS ~= "" then
			AUTH_LINK_WEB_DETAILS = true
		end
	end
end

LOGGER:info("PARENT_EVENT_ID: " .. tostring(PARENT_EVENT_ID) .. ", EVENT_ID: " .. tostring(EVENT_ID))
if (PARENT_EVENT_ID == EVENT_ID) then
	PARENT_EVENT_DESC = ""
else
	PARENT_EVENT_DESC = getPureEventDesc(ASSYST:get_event_desc(PARENT_EVENT_ID))
end


LOGGER:info("get_approval_settings results   AUTH_LINK_NET: " .. tostring(AUTH_LINK_NET) 
	.. ", AUTH_LINK_WEB: " .. tostring(AUTH_LINK_WEB) .. ", AUTH_LINK_WEB_DETAILS: " .. tostring(AUTH_LINK_WEB_DETAILS)
	.. ", ASSYST_USER_FROM_ALIAS: " .. tostring(ASSYST_USER_FROM_ALIAS))
