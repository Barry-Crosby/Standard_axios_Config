-- linked_events_sql.lua
--
-- Prepared for AGS SmartMail Quick Config (Version 3.0)
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
---------------------------------------------------------------------------------------- 
-- Retrieves information on all events linked to the main event
-- Variable Name in a string format:
--    Number of Links:					LINK_COUNT
-- Variable Names in an array format (Lua table):
--    Link Reason Short codes								LINK_REASON_SC
--    Link event type										LINK_TICKET_TYPE
--    Date the Link was created								LINK_INC_DATE
--    short code of assyst User that created the link		LINK_BY_SC
--    name of assyst User that created the link				LINK_BY_N
--    assyst user of the parent linked event				LINK_PAR_ASSYST_USR_N
--    assyst user email of the parent linked event			LINK_PAR_ASSYST_USR_EMAIL
--    link status (open, closed, unknown)					LINK_STATUS
---------------------------------------------------------------------------------------- 

--------------------------------------------------------------------------------------
-- Change log
-- Aug 09 2009	Initial version
-- Dec 18 2012  Updated to explicitly show linked ticket types of Task or Authorisation Task
--------------------------------------------------------------------------------------

sql([[
SELECT  COUNT(incident.incident_ref) AS LINK_COUNT
FROM         link_inc INNER JOIN
                      link_grp ON link_grp.link_grp_id = link_inc.link_grp_id INNER JOIN
                      link_rsn ON link_rsn.link_rsn_id = link_grp.link_rsn_id INNER JOIN
                      link_inc A ON A.link_grp_id = link_grp.link_grp_id INNER JOIN
                      incident ON incident.incident_id = link_inc.incident_id INNER JOIN
                      assyst_usr ON link_grp.assyst_usr_id = assyst_usr.assyst_usr_id
WHERE     (link_inc.incident_id = ]] .. EVENT_ID .. [[ ) AND (A.incident_id <> ]] .. EVENT_ID .. [[ ) 
]])

multi_row_sql([[
		SELECT
		B.incident_id AS LINK_INC_ID, 
		incident_related.incident_ref AS LINK_INC_REF, 
		link_rsn.link_rsn_sc AS LINK_REASON_SC, 
		CASE 
			WHEN inc_data.sub_event_type = 's' then 'Service Request'
			WHEN inc_data.event_type = 't' then 'Task'
			WHEN inc_data.event_type = 'd' then 'Authorisation Task'
			WHEN B.incident_id > 10000000 THEN 'Incident' 
			WHEN B.incident_id < 5000000 THEN 'Problem' 
			WHEN B.incident_id BETWEEN 5000000 AND 10000000 THEN 'Change' 
		ELSE 'Other' 
		END AS LINK_TICKET_TYPE,
		incident_related.date_logged AS LINK_INC_DATE, 
		assyst_usr.assyst_usr_sc AS LINK_BY_SC, 
		assyst_usr.assyst_usr_n AS LINK_BY_N, 
		CASE 
			WHEN assyst_usr_related.assyst_usr_n IS NULL THEN 'N/A' 
			ELSE assyst_usr_related.assyst_usr_n 
		END AS LINK_ASSYST_USR_N, 
		CASE 
			WHEN assyst_usr_related.mail_addr LIKE '%@%' THEN assyst_usr_related.mail_addr
			ELSE 'N/A' 
		END AS LINK_ASSYST_USR_EMAIL, 
		assyst_usr_2.assyst_usr_n AS LINK_ASSYST_USR_N_OLD, 
		CASE 
			WHEN assyst_usr_2.mail_addr LIKE '%@%' THEN assyst_usr_2.mail_addr 
		ELSE 'N/A' 
		END AS LINK_ASSYST_USR_EMAIL_OLD,
		CASE incident_related.inc_status 
			WHEN 'c' THEN 'Closed' 
			WHEN 'o' THEN 'Open' 
			ELSE 'Unknown' END AS LINK_STATUS
		FROM         
		inc_data 
		INNER JOIN incident incident_related ON inc_data.incident_id = incident_related.incident_id 
		INNER JOIN assyst_usr assyst_usr_related on incident_related.assyst_usr_id = assyst_usr_related.assyst_usr_id
		INNER JOIN link_inc 
		INNER JOIN link_grp ON link_grp.link_grp_id = link_inc.link_grp_id 
		INNER JOIN link_rsn ON link_rsn.link_rsn_id = link_grp.link_rsn_id 
		INNER JOIN link_inc B ON B.link_grp_id = link_grp.link_grp_id 
		INNER JOIN incident ON incident.incident_id = link_inc.incident_id 
		INNER JOIN assyst_usr assyst_usr_2 ON incident.assyst_usr_id = assyst_usr_2.assyst_usr_id 
		INNER JOIN assyst_usr ON link_grp.assyst_usr_id = assyst_usr.assyst_usr_id ON incident_related.incident_id = B.incident_id 
		INNER JOIN incident incident_2 
		INNER JOIN assyst_usr assyst_usr_1 ON incident_2.assyst_usr_id = assyst_usr_1.assyst_usr_id ON inc_data.u_num2 = incident_2.incident_id
		WHERE     (link_inc.incident_id = ]] .. EVENT_ID .. [[ ) AND (B.incident_id <> ]] .. EVENT_ID .. [[ ) 
		ORDER BY B.link_grp_id, "LINK_INC_ID"

		]])
