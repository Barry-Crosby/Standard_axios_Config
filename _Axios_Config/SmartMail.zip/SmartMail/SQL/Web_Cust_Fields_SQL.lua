-- Web_Cust_Fields_SQL.lua
--
-- Prepared for AGS SmartMail Quick Config (Version 3.0)
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
----------------------------------------------------------------------------------------
-- Change log
-- 2012-07-10  Changed to retrieve lookup names instead of short codes
--             Remove MY_SINGLE_SELECT_VALUE from Single Select Value
--             Changed to use CUSTOM_FIELD_TICKET_ID if passed
--             Change to handle lookup of empty multiline field
-- 2012-07-30  Change to handle ' in multiline strings 
-- 2012-08-22  Note that this logic is based on form field names which could be duplicated
--			   The logic from this file has been replicated based on short code in Web_Custom_Fields_SC.lua
--------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------- 
-- Custom Field Variables:
-- Custom field types used on the web form
-- Web Custom Field types:
--		 	m = multi select lookup		b = boolean field (check box)		i = integer field		s = single line field
--			o = single select lookup 	d = date field						r = decimal field		n = multiline field
--
-- Windows custom field types
--			s = text		i = integer		d = date		r = real
---------------------------------------------------------------------------------------- 
DB_CONN = assystdb["interface"]
cntr = 0   -- simple counter

if ((CUSTOM_FIELD_TICKET_ID or "") == "") then
	TICKET_ID = EVENT_ID
else
	TICKET_ID = CUSTOM_FIELD_TICKET_ID
end
LOGGER:debug("EVENT_ID: " .. stringify(EVENT_ID) .. ", TICKET_ID: " .. stringify(TICKET_ID) .. ", CUSTOM_FIELD_TICKET_ID: " .. stringify(CUSTOM_FIELD_TICKET_ID))

-- Loop through the field values provided in the calling Lua file
if (CUST_FIELD_LIST ~= nil) then
	for FIELD_NAME, VAR_NAME in pairs(CUST_FIELD_LIST) do
	cntr = cntr + 1
	--																	-- check for custom web form fields
		sql([[select property_type "WEBFIELD_TYPE"
			from jptsys_web_cust_prop
			where jptsys_web_cust_prop_n = ']] .. FIELD_NAME ..[[']])

		if (WEBFIELD_TYPE == nil) then 									-- check for custom fields
			sql([[
				SELECT fld_type "WINFIELD_TYPE"
				FROM jptsys_fld 
				WHERE fld_name =  ']] .. FIELD_NAME ..[[']])
		end
		if (WEBFIELD_TYPE == nil) and (WINFIELD_TYPE == nil) then 		-- check for custom lookup fields
			sql([[ 
				SELECT lookup_id "CUSTLOOKUP_ID"
				FROM jptsys_lookup
				WHERE lookup_sc = ']] .. FIELD_NAME .. [[']])
		end


		if (WEBFIELD_TYPE ~= nil) then	
			-------------------------------
			-- WEB CUSTOM LOOKUP MULTI SELECT 
			-------------------------------
				if WEBFIELD_TYPE == "m" then 
						-- Get the count of selections made on the multi select lookup
						sql([[
							SELECT count(d.jptsys_web_lkup_data_sc) "MULTI_LOOKUP_COUNT"
							FROM 
								jptsys_web_cust_prop_mult m, jptsys_web_cust_prop_cont c, jptsys_web_lkup_data d, jptsys_web_cust_prop jwcp
							WHERE 
								jwcp.jptsys_web_cust_prop_id = c.jptsys_web_cust_prop_id AND
								m.jptsys_web_cust_prop_cont_id = c.jptsys_web_cust_prop_cont_id AND
								d.jptsys_web_lkup_data_id = m.jptsys_web_lkup_data_id AND
								jwcp.jptsys_web_cust_prop_n = ']] .. FIELD_NAME .. [['
								and c.entity_id = ]] .. TICKET_ID)

						-- now get the choices made on the multi select lookup
						multi_row_sql([[
							SELECT d.jptsys_web_lkup_data_n "MULTI_LOOKUP_VALS"
							FROM 
								jptsys_web_cust_prop_mult m, jptsys_web_cust_prop_cont c, jptsys_web_lkup_data d, jptsys_web_cust_prop jwcp
							WHERE 
								jwcp.jptsys_web_cust_prop_id = c.jptsys_web_cust_prop_id AND
								m.jptsys_web_cust_prop_cont_id = c.jptsys_web_cust_prop_cont_id AND
								d.jptsys_web_lkup_data_id = m.jptsys_web_lkup_data_id AND
								jwcp.jptsys_web_cust_prop_n = ']] .. FIELD_NAME .. [['
								and c.entity_id = ]] .. TICKET_ID)
					-- Now loop through the selections to create a value to put in an email
						MULTI_SEL_VAL = ""
						for x = 1, MULTI_LOOKUP_COUNT do
							index = x
							MULTI_SEL_VAL = MULTI_SEL_VAL .. MULTI_LOOKUP_VALS[x] .. linefeedchar
						end
					
					_G[VAR_NAME] = MULTI_SEL_VAL
				end

				-------------------------------
				-- WEB CUSTOM SINGLE SELECT VALUE
				-------------------------------
				if WEBFIELD_TYPE == "o" then	sql([[ 
						SELECT d.jptsys_web_lkup_data_n "]] .. VAR_NAME .. [["
						FROM 
							jptsys_web_cust_prop_cont c, jptsys_web_lkup_data d, jptsys_web_cust_prop jwcp
						WHERE c.single_sel_val_id = d.jptsys_web_lkup_data_id 
							AND jwcp.jptsys_web_cust_prop_id = c.jptsys_web_cust_prop_id 
							AND jwcp.jptsys_web_cust_prop_n = ']] .. FIELD_NAME .. [[' 
							AND c.entity_id = ]] .. TICKET_ID)
				end

				-------------------------------
				 --WEB CUSTOM INTEGER VALUES
				-------------------------------
				if WEBFIELD_TYPE == "i" then 
					sql([[
						SELECT wcpc.integer_val "]] .. VAR_NAME .. [["
						FROM
							jptsys_web_cust_prop AS wcp INNER JOIN
								jptsys_web_cust_prop_cont AS wcpc ON wcp.jptsys_web_cust_prop_id = wcpc.jptsys_web_cust_prop_id
						WHERE     
							wcp.jptsys_web_cust_prop_n = ']] .. FIELD_NAME .. [[' AND wcpc.entity_id = ]] .. TICKET_ID)
				end

				-------------------------------
				-- WEB CUSTOM DECIMAL VALUES
				-------------------------------
				if WEBFIELD_TYPE == "r" then 
					sql([[
						SELECT  wcpc.decimal_val "]] .. VAR_NAME .. [["
						FROM
							jptsys_web_cust_prop AS wcp INNER JOIN
								jptsys_web_cust_prop_cont AS wcpc ON wcp.jptsys_web_cust_prop_id = wcpc.jptsys_web_cust_prop_id
						WHERE
							wcp.jptsys_web_cust_prop_n = ']] .. FIELD_NAME .. [[' AND wcpc.entity_id = ]] ..TICKET_ID)
				end

				-------------------------------
				-- WEB CUSTOM BOOLEAN VALUES
				-------------------------------
				if WEBFIELD_TYPE == "b" then 
					sql([[
						SELECT    wcpc.string_val "]] .. VAR_NAME ..[["
						FROM
							jptsys_web_cust_prop AS wcp INNER JOIN
								jptsys_web_cust_prop_cont AS wcpc ON wcp.jptsys_web_cust_prop_id = wcpc.jptsys_web_cust_prop_id
						WHERE
							wcp.jptsys_web_cust_prop_n = ']] .. FIELD_NAME .. [[' AND wcpc.entity_id = ]] .. TICKET_ID)

					if (_G[VAR_NAME] or "") == "y" then
						_G[VAR_NAME] = (CUSTOM_FIELD_BOOLEAN_TRUE or "true")
					elseif (_G[VAR_NAME] or "") == "n" then
						_G[VAR_NAME] = (CUSTOM_FIELD_BOOLEAN_FALSE or "false")
					end
				end
				
				


				-------------------------------
				--DATE VALUES
				-------------------------------
				if WEBFIELD_TYPE == "d" then 
					if (CUSTOM_FIELD_DATE_FORMAT_SQL or "") ~= "" then
						CUSTOM_DATE_FORMAT = "CONVERT(VARCHAR(10), wcpc.date_val, " .. CUSTOM_FIELD_DATE_FORMAT_SQL .. ")"
					else
						CUSTOM_DATE_FORMAT = "wcpc.date_val"
					end
					sql([[
						SELECT     ]] .. CUSTOM_DATE_FORMAT .. [[ "]] .. VAR_NAME .. [["
						FROM         
							jptsys_web_cust_prop AS wcp INNER JOIN
								jptsys_web_cust_prop_cont AS wcpc ON wcp.jptsys_web_cust_prop_id = wcpc.jptsys_web_cust_prop_id
						WHERE
							wcp.jptsys_web_cust_prop_n = ']] .. FIELD_NAME .. [[' AND wcpc.entity_id = ]] .. TICKET_ID)
				end

				-------------------------------
				-- SINGLE LINE STRING
				-------------------------------
				if WEBFIELD_TYPE == "s" then 
					LOGGER:debug("Single select value - VAR_NAME1: " .. VAR_NAME)
					sql([[
						SELECT  wcpc.string_val "]] .. VAR_NAME .. [["
						FROM
							jptsys_web_cust_prop AS wcp INNER JOIN
								jptsys_web_cust_prop_cont AS wcpc ON wcp.jptsys_web_cust_prop_id = wcpc.jptsys_web_cust_prop_id
						WHERE
							wcp.jptsys_web_cust_prop_n = ']] .. FIELD_NAME .. [[' AND wcpc.entity_id = ]].. TICKET_ID)
					LOGGER:debug("Single select value - VAR_NAME2: " .. VAR_NAME)
				end
				


				-------------------------------
				-- MULTILINE FIELD
				-------------------------------

				if WEBFIELD_TYPE == "n" then 
					sql([[
						SELECT  wcpc.string_val "MY_MULTI_LINE_STRING_VAL"
						FROM 
							jptsys_web_cust_prop AS wcp INNER JOIN
								jptsys_web_cust_prop_cont AS wcpc ON wcp.jptsys_web_cust_prop_id = wcpc.jptsys_web_cust_prop_id
						WHERE
							wcp.jptsys_web_cust_prop_n = ']] .. FIELD_NAME .. [[' AND wcpc.entity_id = ]] .. TICKET_ID)

					-- Now get the descrip grp id value from the custom web contents table.
					sql([[
						SELECT wcpc.descrip_grp_id "MULTI_LINE_DESC_GRP_ID"
						FROM
							jptsys_web_cust_prop_cont wcpc, jptsys_web_cust_prop wcp
						WHERE 
							wcpc.jptsys_web_cust_prop_id = wcp.jptsys_web_cust_prop_id 
							AND wcp.jptsys_web_cust_prop_n = ']] .. FIELD_NAME .. [['
							AND wcpc.entity_id = ]] .. TICKET_ID)
							
					-- Handle empty fields
					MY_MULTI_LINE_STRING_VAL = (MY_MULTI_LINE_STRING_VAL or "")

					if (MULTI_LINE_DESC_GRP_ID or "") == "" then
						MULTI_LINE_DESC_GRP_ID = 0
					end

					if MULTI_LINE_DESC_GRP_ID > 0 then
						--Now find out how many rows it is taking up in the descrip table
						sql([[
							SELECT  count(descrip.descrip_id) "LINES_OF_MULTI_LINE"
							FROM  
								descrip 
							WHERE 
								descrip.descrip_grp_id = ]] .. MULTI_LINE_DESC_GRP_ID) 

						 -- Now get them multiple rows
						 multi_row_sql([[
							SELECT  descrip.descrip "MULTI_LINE_DESC"
							FROM
								descrip 
							WHERE
								descrip.descrip_grp_id = ]] .. MULTI_LINE_DESC_GRP_ID .. [[ ORDER BY ORDER_ID]])
							
						 -- Now join them together
						 
						WHOLE_OF_MULTI_LINE = MY_MULTI_LINE_STRING_VAL
						for i = 1, LINES_OF_MULTI_LINE do
							index = i
							WHOLE_OF_MULTI_LINE = WHOLE_OF_MULTI_LINE .. MULTI_LINE_DESC[i]
						end
						MULTILINE_FIELD_VALUE = WHOLE_OF_MULTI_LINE
					else
						MULTILINE_FIELD_VALUE = MY_MULTI_LINE_STRING_VAL
					end
					
                    _G[VAR_NAME] = MULTILINE_FIELD_VALUE
				end
		elseif (WINFIELD_TYPE ~= nil) then			--- Web custom fields not found, look for Windows custom fields
				-------------------------------
				--  STRING FIELD
				-------------------------------
				if WINFIELD_TYPE == 's' then
					sql ([[
							SELECT cont_string "]] .. VAR_NAME .. [["
							FROM dbo.jptsys_fld v, dbo.jptsys_cont c, dbo.incident i
							WHERE i.incident_id = c.parent_id
							and v.jptsys_fld_id = c.jptsys_fld_id
							and v.fld_name  = ']] .. FIELD_NAME .. [['
							and i.incident_id = ]] .. TICKET_ID)
				end
				-------------------------------
				--  DATE FIELD
				-------------------------------
				if WINFIELD_TYPE == 'd' then
					sql ([[
						SELECT cont_date "]] .. VAR_NAME .. [["
						FROM dbo.jptsys_fld v, dbo.jptsys_cont c, dbo.incident i
						WHERE i.incident_id = c.parent_id
						and v.jptsys_fld_id = c.jptsys_fld_id
						and v.fld_name  = ']] .. FIELD_NAME .. [['
						and i.incident_id = ]] .. TICKET_ID)
				end
				-------------------------------
				--  INTEGER FIELD
				-------------------------------
				if WINFIELD_TYPE == 'i' then
					sql ([[
						SELECT cont_int "]] .. VAR_NAME .. [["
						FROM dbo.jptsys_fld v, dbo.jptsys_cont c, dbo.incident i
						WHERE i.incident_id = c.parent_id
						and v.jptsys_fld_id = c.jptsys_fld_id
						and v.fld_name  = ']] .. FIELD_NAME .. [['
						and i.incident_id = ]] .. TICKET_ID)
				end
				-------------------------------
				--  REAL NUMBER FIELD
				-------------------------------
				if WINFIELD_TYPE == 'r' then
					sql ([[
						SELECT cont_real "]] .. VAR_NAME .. [["
						FROM dbo.jptsys_fld v, dbo.jptsys_cont c, dbo.incident i
						WHERE i.incident_id = c.parent_id
						and v.jptsys_fld_id = c.jptsys_fld_id
						and v.fld_name  = ']] .. FIELD_NAME .. [['
						and i.incident_id = ]] .. TICKET_ID)
				end

		elseif (CUSTLOOKUP_ID ~= nil) then		-- field is a windows custom lookup field
			-- get the lookup value based on the id
					sql ([[
						SELECT lkup_data_n "]] .. VAR_NAME .. [["
						FROM dbo.jptsys_lkup_data l,dbo.jptsys_lookup v, dbo.jptsys_lkup_form f, dbo.jptsys_lkup_cont c, dbo.incident i
						WHERE i.incident_id = c.record_pk
						and c.lkup_data_id = l.lkup_data_id
						and c.lkup_form_id = f.lkup_form_id
						and f.lookup_id = v.lookup_id
						and v.lookup_id  = ]] .. CUSTLOOKUP_ID .. [[
						and i.incident_id = ]] .. TICKET_ID)
		else
			LOGGER:info("The field name " .. FIELD_NAME .. " is not valid. Please check the form and field name and modify your calling lua file")
		end
	CUSTLOOKUP_ID = nil
	WINFIELD_TYPE = nil
	WEBFIELD_TYPE = nil
	end
end

