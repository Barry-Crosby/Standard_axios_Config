-- notify_stakeholders_sql.lua
--
-- Prepared for AGS SmartMail Quick Config (Version 4.0)
--
--------------------------------------------------------------------------------------
-- Change log
-- Apr 30 2012	Initial version
--------------------------------------------------------------------------------------

multi_row_sql([[SELECT
	usr.usr_n "TARGET_NAME", 
	usr.email_add "TARGET_EMAIL"
FROM act_reg 
	INNER JOIN inc_data on act_reg.incident_id = inc_data.incident_id
	INNER JOIN serv_off on inc_data.serv_off_id = serv_off.serv_off_id
	INNER JOIN serv_stakeh on serv_off.serv_id = serv_stakeh.serv_id
	INNER JOIN usr on serv_stakeh.stakeholder_id = usr.usr_id
WHERE act_reg_id = ]] .. ACT_REG_ID)

