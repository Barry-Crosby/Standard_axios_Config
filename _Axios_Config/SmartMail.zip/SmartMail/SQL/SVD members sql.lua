--------------------------------------------------------------------------------------
-- SVD members sql.lua
-- This script will return the name and email address for all members of an SVD with an email address
-- including primary and secondary members
--
-- Variable Names in an array format (Lua table):
--    list of assyst User names in the SVD		SVD_NAME_LIST
--    list of assyst User emails in the SVD		SVD_EMAIL_LIST
--------------------------------------------------------------------------------------
-- Change log
-- 07/28/2008 New file
--
--------------------------------------------------------------------------------------
--
--	To use this for assignments
--		include this file in the sql list
--
--		Change:
--			strAssignee = ASS_SVD_N
--			recipient_name = ASS_SVD_N
--			recipient_email = ASS_SVD_EMAIL
--		To:	
--			strAssignee = SVD_NAME_LIST
--			recipient_name = SVD_NAME_LIST
--			recipient_email = SVD_EMAIL_LIST
--
--------------------------------------------------------------------------------------

SVD_NAME_LIST = {}	
SVD_EMAIL_LIST = {}
	
multi_row_sql([[
select 
	assyst_usr_n 	"SVD_NAME_LIST", 
	mail_addr 		"SVD_EMAIL_LIST"
from assyst_usr
where 
-- Primary SVD members
assyst_usr.assyst_usr_id in (SELECT     assyst_usr.assyst_usr_id
FROM         assyst_usr INNER JOIN
                      serv_dept ON assyst_usr.serv_dept_id = serv_dept.serv_dept_id
WHERE     (serv_dept.serv_dept_sc = ']] .. ASS_SVD_SC .. [[')
	and mail_addr is not null and mail_addr != '')
or 
-- Secondary SVD members
assyst_usr.assyst_usr_id in (SELECT     assyst_usr_svd.assyst_usr_id
FROM         assyst_usr_svd INNER JOIN
                      serv_dept ON assyst_usr_svd.svd_id = serv_dept.serv_dept_id
WHERE     (serv_dept.serv_dept_sc = ']] .. ASS_SVD_SC .. [[')
	and mail_addr is not null and mail_addr != '')
]])

