-- get_decision_results.lua
--
--	Determine what decision was taken
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
---------------------------------------------------------------------------------------- 

--------------------------------------------------------------------------------------
-- Change log
-- Jul 30 2012	New file
--------------------------------------------------------------------------------------

sql([[
SELECT COUNT(answer) NUMBER_OF_ANSWERS
	FROM act_reg
	INNER JOIN rproc_task
		ON rproc_task.incident_id = act_reg.incident_id
	INNER JOIN rproc_dtl
		ON rproc_dtl.rproc_dtl_id = rproc_task.rproc_dtl_id
	INNER JOIN rproc_decisions
		ON rproc_task.rproc_task_id = rproc_decisions.rproc_task_id
	INNER JOIN proc_hdr
		ON proc_hdr.proc_hdr_id = rproc_decisions.rproc_hdr_id
	INNER JOIN act_type
		ON act_type.act_type_id = rproc_dtl.stage_id
WHERE 
	act_reg.act_reg_id = ]] .. ACT_REG_ID )

multi_row_sql([[
SELECT answer 'ANSWER_VALUE',
	proc_hdr_sc 'ANSWER_PROCESS_SC',
	act_type.act_type_sc 'ANSWER_STAGE_SC',
	act_type.act_type_n 'ANSWER_STAGE_N'
	FROM act_reg
	INNER JOIN rproc_task
		ON rproc_task.incident_id = act_reg.incident_id
	INNER JOIN rproc_dtl
		ON rproc_dtl.rproc_dtl_id = rproc_task.rproc_dtl_id
	INNER JOIN rproc_decisions
		ON rproc_task.rproc_task_id = rproc_decisions.rproc_task_id
	INNER JOIN proc_hdr
		ON proc_hdr.proc_hdr_id = rproc_decisions.rproc_hdr_id
	INNER JOIN act_type
		ON act_type.act_type_id = rproc_dtl.stage_id
WHERE 
	act_reg.act_reg_id = ]] .. ACT_REG_ID )

DECISION_ANSWER_VALUE = ""
DECISION_STAGE_SC = ""
DECISION_STAGE_N = ""
DECISION_ANSWER_PROCESS_SC = ""


LOGGER:debug("Decision Results Work  ACT_DESC: " .. ACT_DESC)

-- Find the Answer part of the closure comments
answerStartIndex = string.find((ACT_DESC or ""), "Answer")
LOGGER:debug("answerIndex: " .. stringify(answerStartIndex))
if (answerStartIndex or "") ~= "" then
	
	for x = 1, NUMBER_OF_ANSWERS do		
		-- Get the text after the Answer to look for an answer match (take a few extra characters)
		CHECK_STRING = string.sub(ACT_DESC, tonumber(answerStartIndex), tonumber(answerStartIndex) + string.len(ANSWER_VALUE[x]) + 12)
		
		answerIndex = string.find(CHECK_STRING, ANSWER_VALUE[x])
		LOGGER:debug("answerIndex: " .. stringify(answerIndex) .. ", CHECK_STRING: " .. stringify(CHECK_STRING))
		
		if (answerIndex or "") ~= "" then
			DECISION_ANSWER_VALUE = ANSWER_VALUE[x]
			DECISION_STAGE_SC = ANSWER_STAGE_SC[x]
			DECISION_STAGE_N = ANSWER_STAGE_N[x]
			DECISION_ANSWER_PROCESS_SC = ANSWER_PROCESS_SC[x]
			break
		end
	end
end

LOGGER:debug("Decision Results  DECISION_ANSWER_VALUE: " .. stringify(DECISION_ANSWER_VALUE)
	.. 	", DECISION_STAGE_SC: " .. stringify(DECISION_STAGE_SC)
	.. ", DECISION_STAGE_N: " .. stringify(DECISION_STAGE_N)
	.. ", DECISION_ANSWER_PROCESS_SC: " .. stringify(DECISION_ANSWER_PROCESS_SC))

-- If there was an answer but it doesn't match what was expected flag an error
-- There won't be an answer if the task was closed without taking the decision
if DECISION_ANSWER_VALUE == "" 
		and (answerStartIndex or "") ~= "" then
	LOGGER:error("Unexpected decision response.   Answer not matched in : " .. stringify(ACT_DESC)
			.. ", Expected Answers: " .. stringify(ANSWER_VALUE))
end