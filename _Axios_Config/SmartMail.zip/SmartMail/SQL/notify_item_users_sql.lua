-- notify_item_users_sql.lua
--
-- Prepared for AGS SmartMail Quick Config (Version 4.0)
--
--------------------------------------------------------------------------------------
-- Change log
-- Apr 30 2012	Initial version 
--------------------------------------------------------------------------------------

-- Get Item A and Item B linked users
multi_row_sql([[SELECT 
	usr.usr_n "TARGET_NAME", 
	usr.email_add "TARGET_EMAIL"
FROM act_reg 
	INNER JOIN incident ON act_reg.incident_id = incident.incident_id
	INNER JOIN usr_item on usr_item.item_id = incident.item_id
	INNER JOIN usr ON usr.usr_id = usr_item.user_id 
WHERE act_reg_id = ]] .. ACT_REG_ID .. [[
 UNION
SELECT 
	usr.usr_n "TARGET_NAME",
	usr.email_add "TARGET_EMAIL"
FROM act_reg 
	INNER JOIN incident ON act_reg.incident_id = incident.incident_id
	INNER JOIN inc_data ON incident.incident_id = inc_data.incident_id
	INNER JOIN usr_item on usr_item.item_id = inc_data.item_b_id
	INNER JOIN usr ON usr.usr_id = usr_item.user_id 
WHERE act_reg_id = ]] .. ACT_REG_ID)

