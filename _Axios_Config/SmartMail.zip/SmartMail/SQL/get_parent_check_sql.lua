-- get_parent_check_sql.lua
--
-- Prepared for SmartMail Quick Config
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
---------------------------------------------------------------------------------------- 
-- Change log
-- Jul 31 2012	New File
--------------------------------------------------------------------------------------

sql(
[[SELECT COUNT(incident_id) 'COUNT_TASK_LINK'
	FROM link_grp
	INNER JOIN link_rsn
		ON link_grp.link_rsn_id = link_rsn.link_rsn_id
	INNER JOIN link_inc
		ON link_grp.link_grp_id = link_inc.link_grp_id
	WHERE 
	link_rsn.link_rsn_sc = 'TASK TO RFC'
	AND link_inc.incident_id = ]] .. EVENT_ID)
	
if (COUNT_TASK_LINK or "0") ~= "0" then
	EVENT_IS_PARENT = true
else
	EVENT_IS_PARENT = false
end
