--------------------------------------------------------------------------------------
--	LUA Exercise_XX_sql.lua
--------------------------------------------------------------------------------------
	
sql([[
SELECT
	incident_id "MY_INCIDENT_ID" 
FROM 
	act_regXX
WHERE 
	act_reg.act_reg_id = ]] .. ACT_REG_ID)