-- get_svd_managers_sql.lua
--
-- Prepared for SmartMail Quick Config
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
---------------------------------------------------------------------------------------- 
-- Change log
-- Feb 27 2012	New File
--------------------------------------------------------------------------------------

multi_row_sql(
[[
SELECT assyst_usr.assyst_usr_n "TARGET_NAME", 
		assyst_usr.mail_addr "TARGET_EMAIL"
FROM assyst_usr INNER JOIN
	serv_dept ON assyst_usr.serv_dept_id = serv_dept.serv_dept_id
WHERE serv_dept.serv_dept_sc= ']] .. ASS_SVD_SC .. [['
	and manage_own_svd = 'y'
	and assyst_usr.stat_flag = 'n'
UNION
SELECT assyst_usr.assyst_usr_n "TARGET_NAME", 
		assyst_usr.mail_addr "TARGET_EMAIL"
FROM assyst_usr INNER JOIN
	assyst_usr_svd ON assyst_usr.assyst_usr_id = assyst_usr_svd.assyst_usr_id INNER JOIN
	serv_dept ON assyst_usr_svd.svd_id = serv_dept.serv_dept_id
WHERE serv_dept.serv_dept_sc= ']] .. ASS_SVD_SC .. [['
	and assyst_usr_svd.manage_svd = 'y'
	and assyst_usr.stat_flag = 'n']])
