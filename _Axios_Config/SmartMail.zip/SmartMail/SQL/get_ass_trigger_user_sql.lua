-- get_ass_trigger_user_sql.lua
--
-- Prepared for AGS SmartMail Quick Config (Version 3.0)
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
----------------------------------------------------------------------------------------
-- Used to get the user information associated with assignment trigger levels
-- Variable Names in a string format:
--    Assignment User Short Code:	ASSIGN_TRIGGER_USER_SC
--    Assignment User Name:			ASSIGN_TRIGGER_USER_N
--    Assignment User Email:		ASSIGN_TRIGGER_EMAIL

--------------------------------------------------------------------------------------
-- Change log
-- Oct 15 2009	Initial version
--------------------------------------------------------------------------------------

sql([[
SELECT
	usr.usr_sc "ASSIGN_TRIGGER_USER_SC",
	usr.usr_n "ASSIGN_TRIGGER_USER_N",
	usr.email_add  "ASSIGN_TRIGGER_EMAIL"
FROM       act_reg
		INNER JOIN incident ON incident.incident_id = act_reg.incident_id
		INNER JOIN serv_dept ON serv_dept.serv_dept_id = incident.ass_svd_id
		INNER JOIN usr ON serv_dept.ass_trigger_userid = usr.usr_id
WHERE act_reg.act_reg_id = ]] .. ACT_REG_ID)
