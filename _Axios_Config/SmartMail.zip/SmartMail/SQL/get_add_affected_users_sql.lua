-- get_add_affected_users_sql.lua
--
-- Prepared for SmartMail Quick Config
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
---------------------------------------------------------------------------------------- 
-- Retrieves additional affected users of an event 
-- Variable Names in an array format (Lua table):
--    Affected User Name:	TARGET_NAME
--    Affected User Email:	TARGET_EMAIL
--------------------------------------------------------------------------------------
-- Change log
-- Sep  9 2009	New File
-- Jul 30 2012  Modified to fit custom_target function
--------------------------------------------------------------------------------------

multi_row_sql([[
SELECT     usr.usr_n   		"TARGET_NAME", 
		usr.email_add		"TARGET_EMAIL"
FROM         inc_usr INNER JOIN
                      usr ON inc_usr.usr_id = usr.usr_id LEFT OUTER JOIN
                      assyst_usr ON usr.usr_sc = assyst_usr.assyst_usr_sc
WHERE inc_usr.incident_id = ]] .. EVENT_ID .. [[
ORDER BY inc_usr_id]])
