-- get_incident_item_users_sql.lua
--
-- Prepared for SmartMail Quick Config
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
---------------------------------------------------------------------------------------- 
-- Get Users Linked to Item A or Item B
--------------------------------------------------------------------------------------
-- Change log
-- FEb 22, 2012	New File
--------------------------------------------------------------------------------------

multi_row_sql([[
SELECT usr.usr_sc "USR_SC", 
  usr.usr_n "NAME", 
  usr.email_add "EMAIL"
FROM act_reg 
  INNER JOIN incident ON act_reg.incident_id = incident.incident_id
  INNER JOIN usr_item on usr_item.item_id = incident.item_id
  INNER JOIN usr ON usr.usr_id = usr_item.user_id 
WHERE act_reg_id = ]] .. ACT_REG_ID .. [[
UNION
SELECT usr.usr_sc "USR_SC", 
  usr.usr_n "NAME", 
  usr.email_add "EMAIL"
FROM act_reg 
  INNER JOIN incident ON act_reg.incident_id = incident.incident_id
  INNER JOIN usr_item on usr_item.item_id = incident.item_b_id
  INNER JOIN usr ON usr.usr_id = usr_item.user_id 
WHERE act_reg_id = ]] .. ACT_REG_ID)
