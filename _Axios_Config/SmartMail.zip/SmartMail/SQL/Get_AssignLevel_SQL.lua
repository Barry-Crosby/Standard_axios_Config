--------------------------------------------------------------------------------------
-- Get_AssignLevel_SQL.lua
--------------------------------------------------------------------------------------
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
-- This script finds the trigger level of assignments
-- Variable Names in a string format:
--    Total Internal Assignments:					ASSIGN_TOTAL
--    Flag to show if assignments were internal:	ASSIGN_CHANGED_SVD  (true if assignments occured between SVDs, false if assignments were within an SVD)
--------------------------------------------------------------------------------------
-- Change log
-- 08/11/2009	v1.0 first version
-- 08/19/2009	Revised to determine if threshold reached on last assign
--------------------------------------------------------------------------------------

multi_row_sql([[
	SELECT     
		ass_svd_id "ASSIGNED_SVD_ID"
	FROM         
		act_reg
	WHERE
		incident_id = ]] .. EVENT_ID .. [[ and
		act_reg.act_type_id = 1
	ORDER BY act_reg_id ASC
]])

prev_id = 0
ASSIGN_TOTAL = 0
ASSIGN_CHANGED_SVD = false

if type(ASSIGNED_SVD_ID) == "table" then
	for i, svd_id in ipairs(ASSIGNED_SVD_ID) do
		if svd_id ~= prev_id then
			ASSIGN_TOTAL = ASSIGN_TOTAL + 1
		end
		if prev_id ~= svd_id then
			prev_id = svd_id
			ASSIGN_CHANGED_SVD = true
		else
			ASSIGN_CHANGED_SVD = false
		end
	end
end