-- Auto_select_customFields.lua
--
-- Prepared for AGS SmartMail Quick Config (Version 4.0)
--
-- This script is not supported by Axios Systems. The script is provided as is and Axios Systems
-- accepts no responsibility or liability for the consequences of using this script.
--
----------------------------------------------------------------------------------------
-- Change log
-- 2012-07-10  New file
-- 2012-08-22  Modified to get field SC instead of name
-- 2012-08-23  Corrections to SC changes - corresponding changes required in templates
--------------------------------------------------------------------------------------


sql([[Select u_num2 "CUSTOM_FIELD_TICKET_ID"
	from inc_data
	where inc_data.incident_id = ]] .. EVENT_ID )
	
if (CUSTOM_FIELD_TICKET_ID == 0) then
	CUSTOM_FIELD_TICKET_ID = EVENT_ID
end
LOGGER:debug("CUSTOM_FIELD_TICKET_ID: " .. stringify(CUSTOM_FIELD_TICKET_ID))


sql([[Select COUNT(jptsys_web_cust_prop.jptsys_web_cust_prop_id) "NUMBER_OF_FIELDS"
	from incident inner join inc_data on incident.incident_id = inc_data.incident_id
	inner join jptsys_web_cust_prop_cont on jptsys_web_cust_prop_cont.entity_id = incident.incident_id
	inner join jptsys_web_cust_prop on jptsys_web_cust_prop.jptsys_web_cust_prop_id = jptsys_web_cust_prop_cont.jptsys_web_cust_prop_id
	inner join jptsys_cust_ent on jptsys_cust_ent.jptsys_cust_ent_id=inc_data.ent_id
	where incident.incident_id = ]] .. CUSTOM_FIELD_TICKET_ID )


multi_row_sql([[select jptsys_web_cust_prop.jptsys_web_cust_prop_sc "CUSTOMFIELD_SC",
				 jptsys_web_cust_prop.jptsys_web_cust_prop_n "CUSTOMFIELD_NAME"
			from incident inner join inc_data on incident.incident_id = inc_data.incident_id
	inner join jptsys_web_cust_prop_cont on jptsys_web_cust_prop_cont.entity_id = incident.incident_id
	inner join jptsys_web_cust_prop on jptsys_web_cust_prop.jptsys_web_cust_prop_id = jptsys_web_cust_prop_cont.jptsys_web_cust_prop_id
	inner join jptsys_cust_ent on jptsys_cust_ent.jptsys_cust_ent_id=inc_data.ent_id
	inner join jptsys_def_state_grp on jptsys_web_cust_prop.jptsys_def_state_grp_id = jptsys_def_state_grp.jptsys_def_state_grp_id
	inner join jptsys_def_attr_grp on jptsys_def_state_grp.jptsys_def_state_grp_id = jptsys_def_attr_grp.jptsys_def_state_grp_id
	inner join jptsys_def_attr on jptsys_def_attr_grp.jptsys_def_attr_grp_id = jptsys_def_attr.jptsys_def_attr_grp_id
	where jptsys_def_attr_grp.group_type ='b'
	and jptsys_def_attr.attribute = 'p'
	and incident.incident_id =]] .. CUSTOM_FIELD_TICKET_ID  ..[[
	order by jptsys_def_attr.integer_value]])	
	
CUST_FIELD_LIST = {}
CUST_FIELD_NAME = {}
CUST_FIELD_SC = {}
		for x = 1, NUMBER_OF_FIELDS do
			index = x
			CUST_FIELD_LIST[CUSTOMFIELD_SC[x]]="FIELD_"..tostring(x)
			CUST_FIELD_SC[x]=CUSTOMFIELD_SC[x]
			CUST_FIELD_NAME[x]=CUSTOMFIELD_NAME[x]
		end

LOGGER:debug("CUST_FIELD_LIST: " .. stringify(CUST_FIELD_LIST))
LOGGER:debug("CUST_FIELD_NAME: " .. stringify(CUST_FIELD_NAME))
LOGGER:debug("CUST_FIELD_SC: " .. stringify(CUST_FIELD_SC))

dofile(strPathToSql .. "Web_Cust_Fields_SC.lua")